"use client"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import type { Invoice, InvoiceItem } from "@/components/invoice-creator"
import { Download, FileText, FileIcon as FileWord, FileIcon as FilePdf } from "lucide-react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface InvoiceDisplayProps {
  invoice: Invoice
  onCreateNew: () => void
}

export function InvoiceDisplay({ invoice, onCreateNew }: InvoiceDisplayProps) {
  const [isExporting, setIsExporting] = useState(false)
  const [logoBase64, setLogoBase64] = useState<string | null>(null)
  const invoiceRef = useRef<HTMLDivElement>(null)

  // Convert logo to base64 for Word export
  useEffect(() => {
    const convertLogoToBase64 = async () => {
      try {
        const response = await fetch("/images/voom-logo.png")
        const blob = await response.blob()

        return new Promise<string>((resolve) => {
          const reader = new FileReader()
          reader.onloadend = () => resolve(reader.result as string)
          reader.readAsDataURL(blob)
        })
      } catch (error) {
        console.error("Error converting logo to base64:", error)
        return null
      }
    }

    convertLogoToBase64().then(setLogoBase64)
  }, [])

  const calculateSubtotal = (item: InvoiceItem) => {
    return item.quantity * item.price
  }

  const calculateTotal = () => {
    return invoice.items.reduce((sum, item) => sum + calculateSubtotal(item), 0)
  }

  const handlePrintPDF = () => {
    setIsExporting(true)

    // Create a hidden iframe for printing
    const printFrame = document.createElement("iframe")
    printFrame.style.position = "fixed"
    printFrame.style.right = "0"
    printFrame.style.bottom = "0"
    printFrame.style.width = "0"
    printFrame.style.height = "0"
    printFrame.style.border = "0"
    document.body.appendChild(printFrame)

    // Get the iframe's document
    const frameDoc = printFrame.contentWindow?.document
    if (!frameDoc) {
      setIsExporting(false)
      return
    }

    // Clone the invoice element
    const invoiceElement = invoiceRef.current?.cloneNode(true) as HTMLElement

    // Write the document
    frameDoc.open()
    frameDoc.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Invoice ${invoice.invoiceNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
            .invoice { max-width: 800px; margin: 0 auto; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 8px; }
            th { background-color: #f2f2f2; text-align: left; }
            .header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
            .logo { width: 80px; height: 80px; border-radius: 50%; }
            .company-name { font-size: 24px; font-weight: bold; text-align: center; flex-grow: 1; }
            .invoice-details { display: flex; justify-content: space-between; margin-bottom: 20px; }
            .total { text-align: right; font-weight: bold; }
            .notes { border-top: 1px solid #ddd; padding-top: 20px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="invoice">
            ${invoiceElement.outerHTML}
          </div>
        </body>
      </html>
    `)
    frameDoc.close()

    // Print the iframe
    setTimeout(() => {
      printFrame.contentWindow?.focus()
      printFrame.contentWindow?.print()

      // Remove the iframe after printing
      setTimeout(() => {
        document.body.removeChild(printFrame)
        setIsExporting(false)
      }, 500)
    }, 500)
  }

  const handleExportWord = () => {
    setIsExporting(true)

    // Create a simple HTML representation of the invoice
    const invoiceHtml = `
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
            .invoice { max-width: 800px; margin: 0 auto; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ddd; padding: 8px; }
            th { background-color: #f2f2f2; text-align: left; }
            .header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 20px; }
            .logo { width: 80px; height: 80px; border-radius: 50%; }
            .company-name { font-size: 24px; font-weight: bold; text-align: center; flex-grow: 1; }
            .invoice-details { display: flex; justify-content: space-between; margin-bottom: 20px; }
            .total { text-align: right; font-weight: bold; }
            .notes { border-top: 1px solid #ddd; padding-top: 20px; margin-top: 20px; }
          </style>
        </head>
        <body>
          <div class="invoice">
            <div class="header">
              <img src="${logoBase64}" alt="Voom Logo" class="logo" />
              <div class="company-name">VOOM</div>
              <div style="width: 80px;"></div>
            </div>
            
            <h2>Invoice #${invoice.invoiceNumber}</h2>
            
            <div class="invoice-details">
              <div>
                <h3>Bill To:</h3>
                <p>${invoice.customer}</p>
              </div>
              <div style="text-align: right;">
                <h3>Date:</h3>
                <p>${new Date(invoice.date).toLocaleDateString()}</p>
                <h3>Valid Until:</h3>
                <p>${new Date(invoice.validUntil).toLocaleDateString()}</p>
              </div>
            </div>
            
            <table>
              <thead>
                <tr>
                  <th>Item</th>
                  <th style="text-align: right;">Qty</th>
                  <th style="text-align: right;">Price</th>
                  <th style="text-align: right;">Amount</th>
                </tr>
              </thead>
              <tbody>
                ${invoice.items
                  .map(
                    (item) => `
                  <tr>
                    <td>${item.name}</td>
                    <td style="text-align: right;">${item.quantity}</td>
                    <td style="text-align: right;">${item.price.toFixed(2)} EGP</td>
                    <td style="text-align: right;">${calculateSubtotal(item).toFixed(2)} EGP</td>
                  </tr>
                `,
                  )
                  .join("")}
              </tbody>
              <tfoot>
                <tr>
                  <td colspan="3" style="text-align: right;"><strong>Total:</strong></td>
                  <td style="text-align: right;"><strong>${calculateTotal().toFixed(2)} EGP</strong></td>
                </tr>
              </tfoot>
            </table>
            
            <div class="notes">
              <h3>Notes:</h3>
              <p>${invoice.notes}</p>
            </div>
          </div>
        </body>
      </html>
    `

    // Create a Blob from the HTML content
    const blob = new Blob([invoiceHtml], { type: "application/vnd.ms-word" })

    // Create a download link and trigger it
    const link = document.createElement("a")
    link.href = URL.createObjectURL(blob)
    link.download = `Invoice-${invoice.invoiceNumber}.doc`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)

    setIsExporting(false)
  }

  return (
    <div className="space-y-6 print-container">
      <Card className={`print:shadow-none ${isExporting ? "exporting" : ""}`} ref={invoiceRef}>
        <CardHeader className="pb-2">
          <div className="flex items-center justify-between mb-4">
            <div className="w-24 h-24 relative">
              <img src="/images/voom-logo.png" alt="Voom Logo" className="object-contain w-full h-full rounded-full" />
            </div>
            <h2 className="text-3xl font-extrabold text-center flex-grow tracking-wide">VOOM</h2>
            <div className="w-20"></div> {/* Empty div for balance */}
          </div>

          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="text-xl">Invoice</CardTitle>
              <p className="text-sm text-gray-500">#{invoice.invoiceNumber}</p>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex justify-between">
            <div>
              <h3 className="font-medium">Bill To:</h3>
              <p>{invoice.customer}</p>
            </div>
            <div className="text-right">
              <h3 className="font-medium">Date:</h3>
              <p>{new Date(invoice.date).toLocaleDateString()}</p>
              <h3 className="font-medium mt-2">Valid Until:</h3>
              <p>{new Date(invoice.validUntil).toLocaleDateString()}</p>
            </div>
          </div>

          <div className="border rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-sm font-medium">Item</th>
                  <th className="px-4 py-2 text-right text-sm font-medium">Qty</th>
                  <th className="px-4 py-2 text-right text-sm font-medium">Price</th>
                  <th className="px-4 py-2 text-right text-sm font-medium">Amount</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {invoice.items.map((item) => (
                  <tr key={item.id}>
                    <td className="px-4 py-3 text-sm">{item.name}</td>
                    <td className="px-4 py-3 text-sm text-right">{item.quantity}</td>
                    <td className="px-4 py-3 text-sm text-right">{item.price.toFixed(2)} EGP</td>
                    <td className="px-4 py-3 text-sm text-right">{calculateSubtotal(item).toFixed(2)} EGP</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-50">
                <tr>
                  <td colSpan={3} className="px-4 py-3 text-sm font-medium text-right">
                    Total:
                  </td>
                  <td className="px-4 py-3 text-sm font-medium text-right">{calculateTotal().toFixed(2)} EGP</td>
                </tr>
              </tfoot>
            </table>
          </div>

          <div className="border-t pt-4">
            <h3 className="font-medium mb-2">Notes:</h3>
            <p className="text-sm text-gray-600">{invoice.notes}</p>
          </div>
        </CardContent>
      </Card>

      <div className="flex justify-center gap-4 print:hidden">
        <Button onClick={onCreateNew} className="w-full max-w-xs">
          <FileText className="mr-2 h-4 w-4" />
          Create New Invoice
        </Button>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="w-full max-w-xs">
              <Download className="mr-2 h-4 w-4" />
              Export
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={handlePrintPDF}>
              <FilePdf className="h-4 w-4 mr-2" />
              <span>PDF Document</span>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={handleExportWord}>
              <FileWord className="h-4 w-4 mr-2" />
              <span>Word Document</span>
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <style jsx global>{`
        @media print {
          @page {
            margin: 1cm;
          }
          
          body {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          
          .print\\:hidden {
            display: none !important;
          }
          
          .exporting {
            -webkit-print-color-adjust: exact;
            print-color-adjust: exact;
          }
          
          img {
            print-color-adjust: exact;
            -webkit-print-color-adjust: exact;
          }
        }
      `}</style>
    </div>
  )
}
